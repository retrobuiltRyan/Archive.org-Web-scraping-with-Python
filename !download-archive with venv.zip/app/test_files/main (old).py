import requests
import urllib.parse
from bs4 import BeautifulSoup
import os

def download_file(url, name):
    response = requests.get(url, stream=True)

    with open(name, mode="wb") as file:
        for chunk in response.iter_content(chunk_size=10 * 1024):
            file.write(chunk)
            
def scrape_archive(url):
    response = requests.get(url)
    content = response.content.decode('utf-8')

    soup = BeautifulSoup(content, 'html.parser')

    parent_dir = soup.find('tr')
    first_game = parent_dir.find_next('tr')

    game_url_list = []
    game_name_list = []
    current_game = first_game
    total_size = 0
    
    while current_game != None:
        game_url = urllib.parse.urljoin(url, current_game.a['href'])
        game_name = urllib.parse.unquote(game_url.split('/')[-1])
        game_url_list.append(game_url)
        game_name_list.append(game_name)
        total_size += float(current_game.find_all_next("td")[2].text[:-1])
        current_game = current_game.find_next('tr')
    return game_url_list, game_name_list, total_size


if __name__ == '__main__':

    print("Welcome to the Archive.org scraper!")
    print("Valid urls are like: https://archive.org/download/efgamecubeusa/Game%20Cube%20USA/")
    archive_url = input("\nEnter valid archive.org url: ")
    
    print("Scraping...", end="")
    game_url_list, game_name_list, size = scrape_archive(archive_url)
    print("complete!\n")
    
    print(f"Number of games: {len(game_url_list)}, size: {size:.2f} GB")
    print(f"First game: {game_name_list[0]}")
    print(f"Last game: {game_name_list[-1]}")
    
    target_dir = input("\nEnter full path of target directory: ")
    if os.path.exists(target_dir):
        os.chdir(target_dir)
    else:
        print("Invalid directory!")
        exit()
    
    input("\nPress Enter to continue to download all games...")
    print("Press Ctrl+C to stop the process.")
    print("=========================================")
    
    for game_id in range(len(game_url_list)):
        print(f"Downloading {game_id+1}/{len(game_url_list)}: {game_name_list[game_id]}")
        download_file(game_url_list[game_id], game_name_list[game_id])
        print(f"Downloaded {game_name_list[game_id]}")
        print("=========================================")