import requests
import urllib.parse
import csv
import os
import shutil  # To check available disk space. WARNING! this script will fill a drive without remorse

def get_folder_size(folder_path):
    """Return the total size of all files in a folder."""
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(folder_path):
        for file in filenames:
            file_path = os.path.join(dirpath, file)
            total_size += os.path.getsize(file_path)
    return total_size

def download_file(url, name, download_dir):
    # Check available disk space before starting the download
    total, used, free = shutil.disk_usage(download_dir)  # Get space of the directory where the file will be saved
    free_percentage = (free / total) * 100

    # Print available disk space in GB and as a percentage
    print(f"Available disk space: {free // (1024 * 1024 * 1024)} GB ({free_percentage:.2f}%) free")

    
    # Get the size of the file from the 'Content-Length' header
    #print(f"Starting download from: {url}")
    response = requests.get(url, stream=True)
    
    # Check if the response is successful
    if response.status_code == 200:
        total_size = int(response.headers.get('Content-Length', 0))
    else:
        print(f"Error: Unable to download {url}. Status code: {response.status_code}")
        return
    
    # Define the width of the progress bar (max number of "=" symbols)
    bar_width = 20

    # Path where the file will be saved (in the specified download folder)
    file_path = os.path.join(download_dir, name)

    with open(file_path, mode="wb") as file:
        downloaded = 0
        for chunk in response.iter_content(chunk_size= 100 * 1024):  # 100 KB chunks (1MG chunks is ok, but suffers as background process)
            if chunk:
                file.write(chunk)
                downloaded += len(chunk)

                # Calculate the download progress
                progress = (downloaded / total_size) * 100
                # Calculate the number of "=" symbols to represent progress
                num_equals = int(progress / 100 * bar_width)

                # Generate the progress bar string
                progress_bar = "=" * num_equals + " " * (bar_width - num_equals)

                # Print the progress bar along with the percentage and the file name
                # `\r` returns the cursor to the start of the line
                print(f"\rDownloading {name}: [{progress_bar}] {progress:.2f}% ({downloaded / (1024 * 1024):.2f} MB / {total_size / (1024 * 1024):.2f} MB)", end="")

    print(f"\nDownload complete! File saved as {file_path}")
    
    # Get and print the current size of the folder
    folder_size = get_folder_size(download_dir)
    print(f"Size of folder after download: {folder_size / (1024 * 1024 * 1024):.2f} GB")
    print("=====================================================================")
    print()

# Prompt the user what .csv file is source for all downloads.
print (f" Downloading all games [URLs] from game_list.csv")

# Prompt the user for a folder name
folder_name = input("Please enter the name of the folder to save the downloads: ")


# Create the folder if it doesn't already exist
download_dir = os.path.join(os.getcwd(), folder_name)  # Save in the current working directory
if not os.path.exists(download_dir):
    os.makedirs(download_dir)
    print(f"Folder '{folder_name}' created.")

# Read URLs and file names from CSV file
with open('game_list.csv', mode='r', newline='', encoding='utf-8') as file:
    reader = csv.reader(file)
    next(reader)  # Skip header row if present
    
    # Iterate over the rows in the CSV and download the files sequentially
    for row in reader:
        if len(row) >= 2:  # Ensure there are at least 2 columns (URL and Name)
            url = row[1]  # URL is in the second column
            name = row[0]  # Name is in the first column (or you can use a different column if needed)
            name = urllib.parse.unquote(name)  # Decoding URL-encoded name if necessary
            
            #print(f"\nStarting download of {name}")
            download_file(url, name, download_dir)  # This will download one file at a time
