## Installation

1. Download and install Python. https://www.python.org/downloads/
2. Double click and run `install.bat` file

## Run application

3. Double click and run `run.bat` file
4. Follow the prompts on the terminal screen