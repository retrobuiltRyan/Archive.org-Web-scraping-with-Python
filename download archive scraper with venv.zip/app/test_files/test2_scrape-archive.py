import requests
import urllib.parse
from bs4 import BeautifulSoup
import csv
# https://www.crummy.com/software/BeautifulSoup/bs4/doc/

def scrape_archive(url):
    print(f"Scraping URL: {url}")  # Show the URL being scraped
    response = requests.get(url)
    content = response.content.decode('utf-8')

    soup = BeautifulSoup(content, 'html.parser')

    parent_dir = soup.find('tr')
    first_game = parent_dir.find_next('tr')

    game_url_list = []
    game_name_list = []
    current_game = first_game
    total_size = 0
    
    while current_game != None:
        game_url = urllib.parse.urljoin(url, current_game.a['href'])
        game_name = urllib.parse.unquote(game_url.split('/')[-1])
        game_url_list.append(game_url)
        game_name_list.append(game_name)
        total_size += float(current_game.find_all_next("td")[2].text[:-1])
        current_game = current_game.find_next('tr')
    return game_url_list, game_name_list, total_size

print("Welcome to the Archive.org scraper!")
print("Valid urls are like: https://archive.org/download/efgamecubeusa/Game%20Cube%20USA/")
url = input("\nEnter valid archive.org url: ")

#url = 'https://archive.org/download/sega-genesis-romset-ultra-usa/Sega%20Genesis%20Extras/'

game_url_list, game_name_list, total_size = scrape_archive(url)

print(f"Number of games: {len(game_url_list)}, Total size: {int(total_size)} GB")
# print(f"First game: {game_name_list[0]} \n{game_url_list[0]}")
# print(f"Last game: {game_name_list[-1]} \n{game_url_list[-1]}")
print()

# Open a CSV file to write the game name and URL
with open('game_list.csv', mode='w', newline='', encoding='utf-8') as file:
    writer = csv.writer(file)
    
    # Write the header row (optional)
    writer.writerow(['Game Name', 'Game URL'])
    
    # Write each game name and URL on a new line in the CSV file
    for game_name, game_url in zip(game_name_list, game_url_list):
        writer.writerow([game_name, game_url])
    
print("Game names and URLs have been written to 'game_list.csv'.")

# Wait for the user to press any key before exiting
input("Press 'Enter' to exit...")
