import requests
import urllib.parse
import os

def download_file(url, name):
    # Get the size of the file from the 'Content-Length' header
    print(f"Starting download from: {url}")
    response = requests.get(url, stream=True)
    total_size = int(response.headers.get('Content-Length', 0))
    
    # Define the width of the progress bar (max number of "=" symbols)
    bar_width = 20

    with open(name, mode="wb") as file:
        downloaded = 0
        for chunk in response.iter_content(chunk_size= 100 * 1024):  # 100 KB chunks
            if chunk:
                file.write(chunk)
                downloaded += len(chunk)

                # Calculate the download progress
                progress = (downloaded / total_size) * 100
                # Calculate the number of "=" symbols to represent progress
                num_equals = int(progress / 100 * bar_width)

                # Generate the progress bar string
                progress_bar = "=" * num_equals + " " * (bar_width - num_equals)

                # Print the progress bar along with the percentage and the file name
                # `\r` returns the cursor to the start of the line
                print(f"\rDownloading {name}: [{progress_bar}] {progress:.2f}% ({downloaded / (1024 * 1024):.2f} MB / {total_size / (1024 * 1024):.2f} MB)", end="")

    print(f"\nDownload complete! File saved as {name}")

# URL and file name
url = 'https://archive.org/download/efgamecubeusa/Game%20Cube%20USA/007%20-%20Agent%20Under%20Fire%20%28v1.00%29%28USA%29.iso'
name = urllib.parse.unquote(url.split('/')[-1])

download_file(url, name)
